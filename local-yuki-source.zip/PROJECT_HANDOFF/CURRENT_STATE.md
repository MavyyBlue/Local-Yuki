# Current state — 2026-10-06 owner pass

Live baseline inspected before edits: Local Yuki `387987bee0fea4806742cd0922048dfe47dae8a6`, exact successful Android Actions #28 / `37093263900`; Lockdown `d9874a44bba8a32c95c3a2cf5e63854fe86af33d`, successful bootstrap #31 / `36979273834`. Baseline CI is verified. New-source CI must name the new source, not reuse baseline evidence.

Local Yuki is version0.2.3, physical DB9. It now uses real isolated llama.cpp CPU inference, private model lifecycle/admission receipts, semantic vectors, typed decision/reason/expression, structured living state and reflections, durable scheduled action proposals, owner grant-aware Android executors, persisted resource-bounded initiative jobs and historical Vault migration. Lockdown1.8.0/code10 exposes authenticated typed version1 control with its existing certificate and additive DB1→2 migration.

Automated checks cover foundation/authority boundaries, all historical migrations/Vault restoration, immutable evidence, restart/recovery, malformed/hash-changed imports, degraded resources, concurrency/escalation/expression, reflection/cooldowns, action plans/revoked grants, Accessibility failures and bridge integrity. Real weights are exercised separately through shipping JNI. Host proof is not phone benchmarking, emulator execution or behavioral acceptance.

There is no artificial model freeze and no assistant certification blocker. Full implementation/evidence limits are recorded in [the current architecture](../docs/architecture/OWNER_IMPLEMENTATION_2026-10-06.md). The delivery report supplies exact resulting source identities and final check/CI outcomes. [Galaxy acceptance](PHONE_ACCEPTANCE.md), signed two-app integration and physical second-device migration remain owner authority. No existing signing key or owner database has been reset.

## Galaxy admission repair

Owner installed/opened both apps and reported a generic native model-load rejection. Live Local main `512e2490ad8b54df4435171bfddbed014c3c7cc7` has the delivered tree `f72f121a734630103b03b7367b74f86a2245476f`; exact Android CI #31 / `37511471850` passed. Lockdown bootstrap #33 / `37511528787` passed, committing source `78ed3ed2631be2a84471275b27039f799323f9d2`. This proves published builds, not model/device acceptance.

Version 0.2.1 / CPU adapter v2 removes the isolated loader’s `/proc/self/fd` pathname reopen and uses a duplicated borrowed read-only descriptor for metadata and mmap. Native load diagnostics are bounded and surfaced. No schema/signing/permission changes. [Fix and verification](DESCRIPTOR_LOAD_FIX.md). New exact-source CI and Galaxy retry remain separate from the verified v0.2.0 run.

## Galaxy v0.2.1 results and v0.2.2 timing repair

Exact-source Android Actions `37516394074` passed for live main `7209583417f078ab91baf212fc8640f01dd81af3` / tree `9a53dba97bbb00573e2b6c5d5ed8a01c1cc50004`. Owner confirms SYSTEM_ONE admission on Galaxy with Qwen2.5 1.5B Q4_K_M; LANGUAGE_EXPRESSION and SYSTEM_TWO reject on measured throughput. v0.2.2 / CPU adapter v3 separates fixed preparation from generation, preserves per-role failure measurements and runtime limits from immutable receipts. Existing weights remain; each role needs readmission. New-source CI, other role admission and conversation/device acceptance remain pending. See [timing repair](TIMING_ADMISSION_FIX.md).

## v0.2.3 conversation continuation

Live Local main `c1217f8615b80f4f3d9e303bd64bee87ef51c3a0` has tree `5b73d0cbe042103f0f9502c5a9c638f4f82e8420`; Android Actions `37520823624` and mobile import `37520798057` succeeded. Owner reports all three decoder roles admitted on Galaxy. Conversation fails after roughly 15–20 seconds with the shared generic setup message; successful conversation and broader behavioral acceptance remain unconfirmed. Lockdown main remains `78ed3ed2631be2a84471275b27039f799323f9d2`.

v0.2.3 keeps CPU adapter v3 and existing role receipts, shortens reasoning/expression prompts, constrains generated JSON to compact formatting, supplies the actual output allowance and projects honesty rules as semantic JSON rather than a JVM object string. App-owned failure status identifies the stage, reason and available per-pass timing/output/deadline data. System status and model manifests have Copy controls. This diagnostic status is not a Yuki utterance or continuity evidence. No schema, key, workflow or Lockdown change is needed. The exact Galaxy failure cause still requires the new device result. See [conversation repair](CONVERSATION_FIX.md) for verification and the next owner checkpoint.
